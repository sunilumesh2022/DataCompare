﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCompare.Models
{
    public class Column
    {
        public string Name { get; set; }
        public string Value { get; set; }
        public string Time { get; set; }
        public int Count { get; set; }
    }
}
