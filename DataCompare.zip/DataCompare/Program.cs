﻿using DataCompare.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace DataCompare
{
    internal class Program
    {
        static void Main(string[] args)
        {

            var filePath1 = Directory.GetFiles(Directory.GetCurrentDirectory(), "*v1.0*.json").FirstOrDefault();    // Get json file v1.0
            var filePath2 = Directory.GetFiles(Directory.GetCurrentDirectory(), "*v1.1*.json").FirstOrDefault();    // Get json file v1.1

            if(string.IsNullOrEmpty(filePath1) && string.IsNullOrEmpty(filePath2))  // If files are not found, abort
            {
                Console.WriteLine($"One or both datasets not found, cannot proceed");
                return;
            }

            List<Column> dataset1 = null;
            List<Column> dataset2 = null;

            try
            {
                dataset1 = LoadJson(filePath1); // Load first dataset
                dataset2 = LoadJson(filePath2); // Load second dataset
            }
            catch (Exception ex)    
            {
                Console.WriteLine("One or both datasets not valid JSON files, cannot proceed");
                Console.WriteLine(ex.Message);
                return;
            }

            var tests = new Tests();    // Initialise object to run tests

            Console.WriteLine(tests.sameValueTest(dataset1, dataset2, "Age"));  // Run 'Same value test' for 'Age'
            Console.WriteLine(tests.sameValueTest(dataset1, dataset2, "SEX"));  // Run 'Same value test' for 'SEX'
            Console.WriteLine(tests.CountDifferenceTest(dataset1, dataset2, 0));    // Run 'Count difference test' for threshold 0
            Console.WriteLine(tests.CountDifferenceTest(dataset1, dataset2, 5));    // Run 'Count difference test' for threshold 5
        }

        public static List<Column> LoadJson(string filePath)    // Function to load JSON file
        {
            using (StreamReader r = new StreamReader(filePath))
            {
                string json = r.ReadToEnd();
                JObject jsonObject = JObject.Parse(json);   // Parsing fails if JSON has invalid elements 
                var columnStats = jsonObject["DataSet"]["ColumnStats"].ToString();
                List<Column> columns = JsonConvert.DeserializeObject<List<Column>>(columnStats);
                return columns;
            }
        }
    }
}
