﻿using DataCompare.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCompare
{
    public class Tests
    {
        public string sameValueTest(List<Column> dataset1, List<Column> dataset2, string columnName)
        {
            Console.WriteLine($"Running same value test for {columnName}....");
            var filteredDataSet1 = dataset1.Where(d => d.Name == columnName);
            var filteredDataSet2 = dataset2.Where(d => d.Name == columnName);

            foreach (var item in filteredDataSet1)  // Compare dataset1 with dataset2
            {
                var result = filteredDataSet2.Where(f => f.Value == item.Value);
                if (!result.Any())
                {
                    var output = $"Test failed: {columnName} value {item.Value} is present in dataset 1 but missing in dataset 2";
                    return output;
                }
            }

            foreach (var item in filteredDataSet2)  // Compare dataset2 with dataset1
            {
                var result = filteredDataSet1.Where(f => f.Value == item.Value);
                if (!result.Any())
                {
                    var output = $"Test failed: {columnName} value {item.Value} present in dataset 2 but missing in dataset 1";
                    return output;
                }
            }

            return "Test passed";
        }

        public string CountDifferenceTest(List<Column> dataset1, List<Column> dataset2, int threshold)
        {
            Console.WriteLine($"Running count difference test for threshold {threshold}....");

            if (threshold >= 100)
            {
                return $"Invalid threshold value {threshold}. Theshold should be between 0 and 100.Aborting test";
            }

            foreach (var item1 in dataset1)
            {
                var item2 = dataset2.Where(d => d.Value == item1.Value && d.Time == item1.Time).FirstOrDefault();
                if (item2 == null)  // If item is found in just one dataset, skip to the next item
                {  
                    continue;
                }

                var countDifference = Math.Abs(item2.Count - item1.Count);
                if (countDifference > threshold)
                {
                    var result = $"Test failed: The count difference is {countDifference}, which is greater than the treshold.";
                    return result;
                }
                else
                {
                    return "Test passed";
                }

            }
            return null;
        }
    }
}

